This file has Raw data

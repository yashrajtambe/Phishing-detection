This FOLDER has files which were used to scrap redirecting URLs from the top 550 websites present in the top 1m dataset.
